

def known_seeds(mode):
    if mode == 'training':
        return [1741, 
                3163, 
                6053, 
                2237, 
                8237, 
                8933, 
                4799, 
                1061, 
                2543, 
                8501]
    elif mode == 'test':
        return []



